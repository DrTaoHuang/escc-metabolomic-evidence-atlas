ESCC 代谢组证据图谱

完整解压后双击 index.html。网站默认英文，可在右上角切换简体中文。搜索、详情、专题、记录导出和本地补表无需联网。原始科学名称及引文保留来源文字。

在线网址：https://drtaohuang.github.io/escc-metabolomic-evidence-atlas/
固定版本及离线下载：https://github.com/DrTaoHuang/escc-metabolomic-evidence-atlas/releases/tag/v1.0.0

该资源为研究证据汇总，不包含患者级模型训练数据。报告、研究、来源队列、数据集及记录分别计数；复用时保留原始引文、研究情境及不确定性。
