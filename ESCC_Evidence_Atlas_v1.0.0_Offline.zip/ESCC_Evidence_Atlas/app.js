'use strict';
(() => {
 const D = window.ESCC_DATA, C = window.ESCC_CONTENT || {}, main = document.getElementById('main');
 const esc = value => String(value == null ? '' : value).replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
 const arr = x => Array.isArray(x) ? x : x == null ? [] : [x];
 const str = x => Array.isArray(x) ? x.join('；') : x == null ? '' : String(x);
 const num = n => Number(n||0).toLocaleString('en-US');
 const views = {observations:'代谢物观察',performances:'模型性能',supports:'通路与支持',reports:'研究与来源'};
 const units = {observations:'条观察',performances:'条性能记录',supports:'条支持记录',reports:'篇报告'};
 const uses = {prevention:'病因与预防',diagnosis:'筛查、诊断与同期分期',treatment:'治疗反应与动态监测',prognosis:'预后与复发'};
 const matrices = {serum:'血清',plasma:'血浆',tissue:'组织',urine:'尿液',feces:'粪便',saliva:'唾液',breath:'呼出气相关样本',exosome:'外泌体',other:'其他或未明确'};
 const aliases = {'甲硫氨酸':['methionine'],'蛋氨酸':['methionine'],'丝氨酸':['serine'],'精氨酸':['arginine'],'脯氨酸':['proline'],'谷氨酰胺':['glutamine'],'胆碱':['choline'],'肌苷':['inosine'],'乳酸':['lactate','lactic acid'],'葡萄糖':['glucose'],'嘌呤':['purine'],'鞘脂':['sphingo'],'甘油磷脂':['glycerophospholipid'],'筛查':['screening'],'诊断':['diagnosis','diagnostic'],'复发':['recurrence'],'预后':['prognosis','prognostic']};
 let state = {kind:'observations',q:'',matrix:'',use:'',direction:'',report:'',validation:'',page:1};
 let lastSearch = '#search', filtered = [], toastTimer, topicPage=1, topicQuery='', currentTopic;
 if (!D) { main.innerHTML='<div class="wrap"><div class="error-box">证据资料未能加载。请完整解压离线网站包后打开首页，保留配套的数据与样式文件。</div></div>'; return; }
 const all = Object.fromEntries(Object.keys(views).map(k=>[k,arr(D[k])]));
 const reportMap = new Map(all.reports.map(r=>[r.id,r]));
 const indices = Object.fromEntries(Object.keys(views).map(k=>[k,new Map(all[k].map(r=>[r.id,r]))]));
 const topicMap = new Map(arr(D.topics).map(t=>[t.id,t]));
 const groupMap = new Map(arr(D.groups).map(g=>[g.id,g]));
 const tableTitles = new Map(arr(D.tables).map(t=>[t.id,t.title]));
 const field = (r,pattern) => arr(r.details).filter(d=>pattern.test(d.label||'')).map(d=>str(d.value)).join('；');
 const norm = t => str(t).normalize('NFKC').toLowerCase().trim();
 const matrixTags = r => {
   const m = norm(r.matrix || field(r,/样本基质|Sample matrix|Matrix/i)), result=[];
   if (/serum|血清/.test(m)) result.push('serum'); if (/plasma|血浆/.test(m)) result.push('plasma');
   if (/tissue|组织/.test(m)) result.push('tissue'); if (/urine|尿液/.test(m)) result.push('urine');
   if (/fecal|faecal|feces|faeces|stool|粪便/.test(m)) result.push('feces'); if (/saliva|唾液/.test(m)) result.push('saliva');
   if (/breath|呼出气/.test(m)) result.push('breath'); if (/exosom|外泌体/.test(m)) result.push('exosome');
   return result.length?result:['other'];
 };
 const matrixText = v => matrices[norm(v)] || str(v) || '未明确';
 const dirText = v => ({higher:'升高',lower:'降低',up:'升高',down:'降低',increase:'升高',decrease:'降低',no_difference:'未见差异','no difference':'未见差异',mixed:'方向混合',unc:'无法确定',nr:'未报告',na:'不适用','not applicable':'不适用'})[norm(v)] || str(v) || '未明确';
 const compact = (v,n=190) => {const t=str(v);return t.length>n?t.slice(0,n)+'…':t;};
 const reportMatrices = new Map(all.reports.map(r=>[r.id,new Set()]));
 for(const kind of ['observations','performances','supports']) for(const r of all[kind]) {
   r._matrices=matrixTags(r);
   for(const id of arr(r.reportIds)) for(const m of r._matrices) reportMatrices.get(id)?.add(m);
 }
 for(const r of all.reports) r._matrices=[...(reportMatrices.get(r.id)||[])];
 for(const kind of Object.keys(views)) for(const r of all[kind]) {
   r._search=norm([r.id,r.title,r.matrix,r.comparison,r.timepoint,r.direction,r.identity,r.validation,r.source,r.doi,r.year,arr(r.reportIds).join(' '),arr(r.use).map(x=>uses[x]).join(' '),arr(r.details).map(d=>d.label+' '+str(d.value)).join(' '),arr(r.reportIds).map(id=>{let p=reportMap.get(id);return p?[p.title,p.citation,p.doi].join(' '):'';}).join(' ')].join(' '));
 }
 for(const kind of Object.keys(views))for(const r of all[kind])r._search+=' '+norm([arr(r.use).map(key=>window.ESCC_I18N?.uiText(uses[key])).join(' '),window.ESCC_I18N?.evidenceText(r.validationRole||'')].join(' '));
 const path = (route,params={}) => '#'+route+(Object.keys(params).length?'?'+new URLSearchParams(Object.entries(params).filter(([,v])=>v!==''&&v!=null)).toString():'');
 const searchPath = params => path('search',params);
 const detailPath = (kind,id) => '#detail/'+kind+'/'+encodeURIComponent(id);
 const tag = (text,cls='') => '<span class="tag '+cls+'">'+esc(text)+'</span>';
 const useTags = r => arr(r.use).map(u=>uses[u]?tag(uses[u],'tag-accent'):'').join('');
 const reportLinks = r => arr(r.reportIds).map(id=>reportMap.has(id)?'<a href="'+detailPath('reports',id)+'">'+esc(id)+'</a>':esc(id)).join(' · ');
 const detailFields = details => '<dl class="detail-fields">'+arr(details).filter(d=>d&&d.label&&str(d.value)!=='').map(d=>'<div><dt>'+esc(d.label)+'</dt><dd>'+esc(str(d.value))+'</dd></div>').join('')+'</dl>';
 const safePublic = r => Object.fromEntries(Object.entries(r).filter(([k])=>!k.startsWith('_')));
 const tableLinks = ids => arr(ids).filter(x=>/^S\d+$/.test(x)).map(id=>'<a href="downloads/'+id+'.docx" download title="'+esc(tableTitles.get(id)||id)+'">补充表 '+esc(id)+'</a>').join(' · ');
 const localize = () => window.ESCC_I18N?.apply();
 const notify = msg => {const box=document.getElementById('toast');box.textContent=msg;box.classList.add('show');localize();clearTimeout(toastTimer);toastTimer=setTimeout(()=>box.classList.remove('show'),3500);};
 const download = (name,content,type) => {const url=URL.createObjectURL(new Blob([content],{type}));const a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),3000);};
 const icon = (name,cls='') => '<img class="ui-icon '+cls+'" src="assets/icons/'+({history:'rotate-ccw-clock',filter:'funnel'}[name]||name)+'.svg" alt="" aria-hidden="true" width="24" height="24" decoding="async">';
 const wrap = html => '<div class="wrap">'+html+'</div>';
 const eyes={'EVIDENCE SEARCH':'检索与追溯','SCIENTIFIC INTERPRETATION':'科学解释','CLINICAL USES':'临床用途','RESOURCES & READING GUIDE':'下载与使用','CLINICAL EVIDENCE':'用途证据','SCIENTIFIC EVIDENCE':'科学主题'};
 const pageTitle = (eye,title,description) => '<div class="page-title"><div class="eyebrow">'+esc(eyes[eye]||eye)+'</div><h1>'+esc(title)+'</h1><p>'+esc(description)+'</p></div>';
 function home() {
   const samples=[['tissue','组织','microscope'],['serum','血清','test-tube'],['plasma','血浆','test-tube'],['urine','尿液','flask-conical'],['feces','粪便','package-open'],['saliva','唾液','droplets'],['breath','呼出气','wind'],['exosome','外泌体','layers'],['all','全部样本','test-tubes']];
   const cards=[['observations',D.counts.observations,'代谢物观察','保留原始名称、样本、时点与方向','flask-conical','teal'],['performances',D.counts.performances,'模型性能记录',num(D.counts.models)+'个模型标识，逐来源查看验证','activity','blue'],['supports',D.counts.supports,'通路与生物学支持','区分人体发现与不同实验层级','network','violet']];
   main.innerHTML='<section class="hero-stage"><img class="hero-art" src="assets/metabolomics-hero.png" alt="" aria-hidden="true" width="1983" height="793" fetchpriority="high"><div class="wrap hero-shell"><div class="hero-content"><div class="hero-badge">'+icon('network','icon-light')+'<span>人体研究 · ESCC</span></div><h1>ESCC 代谢组<br><span>证据图谱</span></h1><p class="hero-copy">检索人体食管鳞状细胞癌代谢组研究，查看分子身份、研究情境、结果与验证，追溯科学解释和临床用途的依据。</p><form class="searchbar" id="home-search" role="search">'+icon('search')+'<input id="home-q" aria-label="检索代谢物、通路或文献" placeholder="代谢物、通路、作者或临床用途" autocomplete="off"><button class="btn btn-primary" type="submit">查证据</button></form><div class="example-searches"><span>试着查：</span><button data-query="甲硫氨酸">甲硫氨酸</button><button data-query="丝氨酸">丝氨酸</button><button data-query="purine" data-kind="supports">嘌呤相关支持</button><button data-browse="performances" data-use="diagnosis">诊断模型</button></div></div><aside class="hero-source"><div class="source-card-title">'+icon('database','icon-light')+'<h2>人体研究与来源</h2></div><p>按报告、研究、来源和数据集分别组织</p><div class="entity-grid">'+[['reports','纳入报告'],['studies','研究单元'],['cohorts','来源队列节点'],['datasets','分析数据集']].map(([key,label])=>'<div><b>'+num(D.counts[key])+'</b><span>'+label+'</span></div>').join('')+'</div><p class="entity-note">节点数量用于来源治理；具体信号的独立复现须结合身份、情境和来源关系判断。</p></aside></div></section>'+wrap('<section class="home-stats" aria-label="证据记录入口">'+cards.map(([kind,count,title,description,symbol,color])=>'<a class="stat-link tone-'+color+'" href="'+searchPath({kind})+'"><span class="stat-icon">'+icon(symbol)+'</span><div><span class="number">'+num(count)+'</span><span class="stat-name">'+title+'</span><small>'+description+'</small></div></a>').join('')+'</section><section class="sample-section" aria-labelledby="sample-title"><div class="section-head"><div><h2 id="sample-title">按样本寻找证据</h2><p>选择样本类型，查看对应的代谢物观察。</p></div><a class="link-text" href="#search">全部证据</a></div><div class="sample-grid">'+samples.map(([matrix,label,symbol])=>'<a class="sample-link sample-'+matrix+'" href="'+searchPath({kind:'observations',matrix:matrix==='all'?'':matrix})+'" aria-label="检索'+esc(matrix==='all'?'全部样本':matrices[matrix])+'代谢物观察"><span class="sample-symbol">'+icon(symbol)+'</span><span>'+label+'</span></a>').join('')+'</div></section><div class="section-head"><div><h2>从你的问题开始</h2><p>查具体信号，也可以按科学问题或临床用途阅读。</p></div><a class="link-text" href="#resources">阅读说明</a></div><section class="entry-grid"><a class="entry-card tone-teal" href="#science"><div class="entry-top"><span class="entry-symbol">'+icon('network')+'</span><span class="entry-index">科学解释</span></div><h3>这些信号能解释什么？</h3><p>查看分子身份、人体观察、方向一致性及生物学支持，理解不同情境下的解释范围。</p><span class="entry-label">浏览科学解释</span></a><a class="entry-card tone-blue" href="#clinical"><div class="entry-top"><span class="entry-symbol">'+icon('scan-search')+'</span><span class="entry-index">临床用途</span></div><h3>能够支持哪一种用途？</h3><p>按病因与预防、筛查与诊断、治疗、预后与复发，查看目标人群与验证条件。</p><span class="entry-label">浏览四类临床用途</span></a><a class="entry-card tone-violet" href="'+searchPath({kind:'reports'})+'"><div class="entry-top"><span class="entry-symbol">'+icon('book-open')+'</span><span class="entry-index">研究来源</span></div><h3>证据来自哪些研究？</h3><p>沿报告、研究单元、来源队列和分析数据集，查找人群、测量条件与原报告定位。</p><span class="entry-label">浏览研究与来源</span></a></section><div class="notice">观察、支持和性能数量均为记录层计数。同一化合物、模型或来源在不同分析情境中的记录分别保留；这些数量不代表独特化合物、独立检测或患者总数。</div><div class="section-head"><h2>查到结果后，继续核对</h2></div><section class="home-flow">'+[['microscope','确认测量与情境','原始名称、身份分辨率、基质、比较和采样时点。'],['layers','查看全部相关结果','同时保留同向、相反、阴性和无法明确判断的结果。'],['book-open','追溯来源与验证','核对原报告、来源关系、证据边界与下一步验证条件。']].map(([symbol,title,description])=>'<div>'+icon(symbol)+'<h3>'+title+'</h3><p>'+description+'</p></div>').join('')+'</section>');
 }
 function decoratePage(name) {
   const symbols={search:'search',science:'network',clinical:'scan-search',resources:'book-open'};
   const heading=main.querySelector('.page-title');
   if(heading)heading.insertAdjacentHTML('afterbegin','<span class="page-symbol">'+icon(symbols[name]||'book-open')+'</span>');
   main.querySelectorAll('[data-kind-tab]').forEach(el=>el.insertAdjacentHTML('afterbegin',icon({observations:'flask-conical',performances:'activity',supports:'network',reports:'book-open'}[el.dataset.kindTab])));
   main.querySelectorAll('#export-results,[data-export-one],[data-export-topic]').forEach(el=>el.insertAdjacentHTML('afterbegin',icon('download')));
   main.querySelectorAll('#result-search .btn-primary').forEach(el=>el.insertAdjacentHTML('afterbegin',icon('search','icon-light')));
   const clinicalSymbols=['shield-check','scan-search','activity','history'];
   main.querySelectorAll('.topic-card').forEach((card,i)=>{card.classList.add('clinical-card','clinical-tone-'+i);card.insertAdjacentHTML('afterbegin','<span class="clinical-symbol">'+icon(clinicalSymbols[i])+'</span>');});
   main.querySelectorAll('.topic-item').forEach(card=>card.insertAdjacentHTML('afterbegin','<span class="topic-symbol">'+icon('network')+'</span>'));
   main.querySelectorAll('.resource-card').forEach((card,i)=>card.insertAdjacentHTML('afterbegin','<span class="resource-symbol">'+icon(['package-open','database','book-open'][i])+'</span>'));
   main.querySelectorAll('.side-card h3').forEach(title=>title.insertAdjacentHTML('afterbegin',icon(/来源/.test(title.textContent)?'database':/保存/.test(title.textContent)?'download':/补表/.test(title.textContent)?'book-open':'layers')));
   decorateRecordTags();
 }
 function decorateRecordTags() {
   main.querySelectorAll('.record-meta .tag').forEach(el=>{if(el.querySelector('.ui-icon'))return;const key=Object.keys(matrices).find(k=>matrices[k]===el.textContent);if(key)el.insertAdjacentHTML('afterbegin',icon({tissue:'microscope',serum:'test-tube',plasma:'test-tube',urine:'flask-conical',feces:'package-open',saliva:'droplets',breath:'wind',exosome:'layers',other:'pipette'}[key]));});
 }
 function options(values,current,labelFn=x=>x) { return values.map(v=>'<option value="'+esc(v)+'"'+(v===current?' selected':'')+'>'+esc(labelFn(v))+'</option>').join(''); }
 function search(params) {
   state={kind:params.get('kind')||'observations',q:params.get('q')||'',matrix:params.get('matrix')||'',use:params.get('use')||'',direction:params.get('direction')||'',report:params.get('report')||'',validation:params.get('validation')||'',page:Math.max(1,parseInt(params.get('page')||'1')||1)};
   if(!views[state.kind]) state.kind='observations';
   if(!all[state.kind].some(r=>arr(r.use).length))state.use='';
   const rows=all[state.kind], dirs=[...new Set(rows.map(r=>str(state.kind==='performances'?(r.validationRole||r.direction):r.direction)).filter(Boolean))].sort();
   main.innerHTML=wrap(pageTitle('EVIDENCE SEARCH','证据检索','按关键词和研究情境筛选，打开每条记录查看完整证据与来源。')+'<div class="tabs" role="tablist" aria-label="证据类型">'+Object.entries(views).map(([k,v])=>'<button class="tab '+(state.kind===k?'active':'')+'" role="tab" aria-selected="'+(state.kind===k)+'" data-kind-tab="'+k+'">'+v+'<small>'+num(all[k].length)+'</small></button>').join('')+'</div><section class="filter-panel" aria-label="检索条件"><form class="searchbar" id="result-search" role="search"><input id="query" aria-label="检索关键词" value="'+esc(state.q)+'" placeholder="名称、稳定标识、作者、用途或来源" autocomplete="off"><button class="btn btn-primary" type="submit">检索</button></form><div class="filter-row"><label class="filter-field">样本基质<select id="matrix-filter"><option value="">全部基质</option>'+options(Object.keys(matrices),state.matrix,x=>matrices[x])+'</select></label><label class="filter-field">临床用途<select id="use-filter"><option value="">全部用途与未映射记录</option>'+options(Object.keys(uses),state.use,x=>uses[x])+'</select></label><label class="filter-field">'+(state.kind==='performances'?'评估角色':'结果方向')+'<select id="direction-filter"><option value="">全部状态</option>'+options(dirs,state.direction,dirText)+'</select></label></div><details class="advanced"'+(state.report?' open':'')+'><summary>限定报告来源</summary><div class="filter-row"><label class="filter-field">报告<select id="report-filter"><option value="">全部报告</option>'+options([...reportMap.keys()],state.report,id=>id+' · '+compact(reportMap.get(id).citation||reportMap.get(id).title,85))+'</select></label></div></details><div class="filter-actions"><div id="active-filters" class="active-filters"></div><button class="btn" id="clear-filters" type="button">清除筛选</button></div></section><div class="result-toolbar"><div id="result-count" role="status" aria-live="polite"></div><button class="btn" id="export-results" type="button">导出筛选结果</button></div><div id="result-list" class="result-list"></div><div id="pagination" class="pagination"></div><p class="muted" style="font-size:.875rem">关键词命中可来自名称、研究情境或来源文字；名称相关记录仍需分别核对分子身份。当前筛选无匹配记录，不代表该问题不存在证据。</p>');
   renderResults();
   if(!rows.some(r=>arr(r.use).length)){const select=document.getElementById('use-filter');select.disabled=true;select.innerHTML='<option value="">用途阅读见临床专题</option>';}
 }
 function matches(r,q) {
   if(!q.trim()) return true;
   const tokens=norm(q).split(/\s+/).filter(Boolean);
   return tokens.every(t=>[t,...(aliases[t]||[])].some(word=>r._search.includes(word)));
 }
 function recordCard(r,kind) {
   let meta=useTags(r), summary='';
   if(kind==='reports') {
     summary='<dl><dt>报告</dt><dd>'+esc(r.citation||r.title)+'</dd><dt>来源关系</dt><dd>'+esc([arr(r.studyIds).join(' · '),arr(r.cohortIds).join(' · '),arr(r.datasetIds).join(' · ')].filter(Boolean).join('；'))+'</dd><dt>DOI</dt><dd>'+esc(r.doi||'未明确')+'</dd></dl>';
   } else {
     if(r.matrix) meta=tag(matrixText(r.matrix))+meta;
     summary='<dl>'+[['比较',r.comparison],['时点',r.timepoint],[(kind==='performances'?'验证':'身份'),kind==='performances'?r.validation:r.identity]].filter(([,v])=>str(v)).map(([label,v])=>'<dt>'+label+'</dt><dd title="'+esc(str(v))+'">'+esc(compact(v))+'</dd>').join('')+'</dl>';
   }
   return '<article class="record-card"><div><a class="record-title" href="'+detailPath(kind,r.id)+'">'+esc(r.title||r.id)+'</a><span class="record-id">'+esc(r.id)+(r.modelId?' · 模型 '+esc(r.modelId):'')+'</span><div class="record-meta">'+meta+'</div></div><div class="record-summary">'+summary+'</div><div class="record-side"><span class="direction">'+esc(kind==='reports'?(r.year||''):dirText(r.validationRole||r.direction||r.validationCategory))+'</span><div class="source-links">'+(kind==='reports'?'<a href="'+detailPath(kind,r.id)+'">查看研究详情</a>':reportLinks(r))+'</div></div></article>';
 }
 function renderResults() {
   filtered=all[state.kind].filter(r=>matches(r,state.q)&&(!state.matrix||r._matrices.includes(state.matrix))&&(!state.use||arr(r.use).includes(state.use))&&(!state.direction||str(state.kind==='performances'?(r.validationRole||r.direction):r.direction)===state.direction)&&(!state.report||arr(r.reportIds).includes(state.report)||r.id===state.report));
   const size=20,pages=Math.max(1,Math.ceil(filtered.length/size));state.page=Math.min(state.page,pages);
   document.getElementById('result-count').innerHTML='<strong>'+num(filtered.length)+' '+units[state.kind]+'</strong><p>全部 '+num(all[state.kind].length)+' '+units[state.kind]+(state.kind==='performances'?' · '+num(new Set(filtered.map(r=>r.modelId).filter(Boolean)).size)+'个模型标识':'')+'</p>';
   document.getElementById('active-filters').innerHTML=[state.q&&tag('关键词：'+state.q),state.matrix&&tag(matrices[state.matrix]),state.use&&tag(uses[state.use]),state.direction&&tag(dirText(state.direction)),state.report&&tag(state.report)].filter(Boolean).join('')||'<span class="muted">当前显示全部记录</span>';
   document.getElementById('result-list').innerHTML=filtered.length?filtered.slice((state.page-1)*size,state.page*size).map(r=>recordCard(r,state.kind)).join(''):'<div class="empty"><h3>当前筛选条件下无匹配记录</h3><p>可以减少限定条件、使用原始名称或更换关键词。</p><button class="btn" data-clear="true">清除筛选</button></div>';
   document.getElementById('pagination').innerHTML=filtered.length?'<button class="btn" data-page="'+(state.page-1)+'"'+(state.page===1?' disabled':'')+'>上一页</button><span>'+state.page+' / '+pages+'</span><button class="btn" data-page="'+(state.page+1)+'"'+(state.page===pages?' disabled':'')+'>下一页</button>':'';
   lastSearch=searchPath(state);history.replaceState(null,'',lastSearch);decorateRecordTags();localize();
 }
 function detail(kind,id) {
   const r=indices[kind]?.get(id);
   if(!r){main.innerHTML=wrap('<div class="empty"><h1>未找到此记录</h1><p>请从证据检索重新选择记录。</p><a class="btn" href="#search">返回检索</a></div>');return;}
   const isReport=kind==='reports';
   const primary=[['样本基质',matrixText(r.matrix)],['临床比较',r.comparison],['采样时点',r.timepoint],...(kind==='performances'?[['评估角色',r.validationRole],['原记录状态',r.direction]]:[['结果方向',dirText(r.direction||r.validation)]]),[kind==='performances'?'输入特征':kind==='supports'?'证据对象类型':'分子身份',r.identity],['验证方式',r.validation]].filter(([,v])=>str(v));
   const sourceReports=isReport?[r]:arr(r.reportIds).map(x=>reportMap.get(x)).filter(Boolean);
   const group=kind==='observations'?(groupMap.has(r.groupId)?[groupMap.get(r.groupId)]:arr(D.groups).filter(g=>arr(g.recordIds||g.observationIds).includes(id))):[];
   const peers=kind==='performances'&&r.modelId?all.performances.filter(x=>x.modelId===r.modelId&&x.id!==r.id):[];
   const sourceSections=sourceReports.map(p=>'<div class="detail-section"><h3>'+esc(p.id)+'</h3><p class="source-citation">'+esc(p.citation||p.title)+'</p>'+(/^(10\.\d{4,9}\/)/.test(p.doi||'')?'<p class="source-note"><a href="https://doi.org/'+encodeURI(p.doi)+'" target="_blank" rel="noopener noreferrer">打开论文 DOI</a> · 外部论文页面需要联网</p>':'')+(!isReport?'<p class="source-note"><a href="'+detailPath('reports',p.id)+'">查看报告与来源详情</a></p>':'')+'</div>').join('');
   main.innerHTML=wrap('<div class="breadcrumb"><a href="#home">首页</a><span>/</span><a href="'+lastSearch+'">'+esc(views[kind])+'</a><span>/</span><span>'+esc(r.id)+'</span></div><header class="detail-header"><div class="eyebrow">'+esc(views[kind])+'</div><h1>'+esc(r.title||r.id)+'</h1><div class="record-meta">'+tag(r.id)+(r.modelId?tag('模型 '+r.modelId):'')+useTags(r)+'</div></header><div class="detail-layout"><div>'+(!isReport?'<dl class="evidence-strip">'+primary.map(([l,v])=>'<div><dt>'+esc(l)+'</dt><dd>'+esc(str(v))+'</dd></div>').join('')+'</dl>':'')+(group.length?'<div class="notice">综合角色：'+esc(field(group[0],/综合类别/))+'。具体身份、来源资格与可比性依据见下方综合分组。</div>':'')+'<section class="detail-section"><h2>'+(isReport?'研究与来源资料':'完整证据记录')+'</h2>'+detailFields(r.details)+'</section>'+(isReport&&arr(r.quality).length?'<section class="detail-section"><h2>分领域质量与适用性</h2><p class="muted">各领域分别评价，不合成总质量分。</p>'+arr(r.quality).map((q,i)=>'<details class="disclosure"><summary>'+esc(q.title||q.domain||'评价领域 '+(i+1))+'</summary>'+detailFields(q.details||[{label:'评价框架',value:q.framework},{label:'领域判断',value:q.judgement||q.judgment},{label:'判断依据',value:q.evidence||q.rationale},{label:'原报告定位',value:q.source}])+'</details>').join('')+'</section>':'')+(group.length?'<section class="detail-section"><h2>可比性与综合分组</h2>'+group.map(g=>'<details class="disclosure"><summary>'+esc(g.title||g.id)+'</summary>'+detailFields(g.details)+'<p class="source-note">'+num(arr(g.recordIds||g.observationIds).length)+'条观察按原核准规则分组；分组本身不等于独立复现或定量合并资格。</p>'+arr(g.recordIds||g.observationIds).map(x=>'<a class="mini-record" href="'+detailPath('observations',x)+'">'+esc(indices.observations.get(x)?.title||x)+'<span>'+esc(x)+'</span></a>').join('')+'</details>').join('')+'</section>':'')+(peers.length?'<section class="detail-section"><h2>同一模型标识的其他性能记录</h2><p class="muted">各项结果保留评估人群、数据集及验证角色。</p>'+peers.map(x=>'<a class="mini-record" href="'+detailPath('performances',x.id)+'">'+esc(x.title)+'<span>'+esc(x.id)+' · '+esc(compact(x.validation,110))+'</span></a>').join('')+'</section>':'')+'<section class="detail-section"><h2>原报告与证据定位</h2>'+sourceSections+(r.source?'<div class="notice source-citation">'+esc(str(r.source))+'</div>':'')+'</section></div><aside><div class="side-card"><h3>来源关系</h3><p>报告：'+(reportLinks(r)||esc(r.id))+'</p><p>研究单元：'+esc(arr(r.studyIds).join(' · ')||'未明确')+'</p><p>来源队列节点：'+esc(arr(r.cohortIds).join(' · ')||'未明确')+'</p><p>分析数据集：'+esc(arr(r.datasetIds).join(' · ')||'未明确')+'</p><p class="source-note">来源节点与数据集数量不直接表示独立验证次数。</p></div><div class="side-card"><h3>对应完整补表</h3><p>'+tableLinks(r.tableIds||[isReport?'S3':kind==='performances'?'S9':kind==='supports'?'S18':'S17'])+'</p><a class="btn" href="#resources">字段与状态释义</a></div><div class="side-card"><h3>保存这条证据</h3><p>保留完整字段、来源关系及科学限制。</p><button class="btn" data-export-one="'+esc(r.id)+'" data-export-kind="'+kind+'">下载记录</button><button class="btn" data-copy-citation="'+esc(sourceReports.map(x=>x.citation||x.title).join('\n'))+'">复制文献引文</button></div><div class="side-card"><h3>阅读边界</h3><p>人体观察、生物学解释和临床验证分别判断。名称相似、方向一致或较高性能均需结合具体研究条件解释。</p></div></aside></div>');
 }
 function topicDetails(t) {
   return (t.details?.length?detailFields(t.details):'')+(arr(t.records).length?arr(t.records).map((r,i)=>'<details class="disclosure"><summary>'+esc(r.title||r.id||'证据条目 '+(i+1))+'</summary>'+detailFields(r.details)+'<p class="source-note">'+reportLinks(r)+' · '+tableLinks(r.tableIds||t.tableIds)+'</p></details>').join(''):'');
 }
 function science() {
   const topics=arr(D.topics).filter(t=>t.category==='science'||t.category==='scientific');
   main.innerHTML=wrap(pageTitle('SCIENTIFIC INTERPRETATION','科学解释','沿分子身份、人体观察、可比性和生物学支持，阅读不同研究情境中的代谢信号。')+'<div class="notice">人体、离体、细胞、类器官和动物支持分别保留证据层级。通路富集、相关或同向变化的解释范围，须结合原研究设计和测量条件。</div><div class="topic-list">'+topics.map(t=>'<article class="topic-item"><h3>'+esc(t.title)+'</h3><p>'+esc(compact(t.description||field(t,/当前证据|解释|Evidence|支持/),230))+'</p><a href="#topic/'+encodeURIComponent(t.id)+'">查看完整主题证据</a></article>').join('')+'</div><div class="inline-actions"><a class="btn" href="'+searchPath({kind:'supports'})+'">检索全部通路与支持</a><a class="btn" href="'+searchPath({kind:'observations'})+'">检索代谢物观察</a></div>');
 }
 const clinicalCopy=[['prevention','病因与预防','查看诊断前采样、癌前病变进展、距确诊时间及混杂控制。','观察性关联与诊断前预测分别解释；现有相关结果不能直接确立预防干预获益。','S12'],['diagnosis','筛查、诊断与同期分期','查看实际招募人群、目标病变、对照谱、参考标准与锁定验证。','病例与健康对照中的判别表现需保留原人群范围；同期分期与未来事件预测分别判断。','S13'],['treatment','治疗反应与动态监测','区分治疗前预测、治疗过程中的患者内变化及不同治疗情境。','反应关联、疗效预测和检测指导治疗的患者获益分别评价。','S14'],['prognosis','预后与复发','查看预测起点、结局窗口、校准、独立来源及动态监测提前量。','诊断面板的验证不移用到生存评分；监测价值还需临床增量与效用证据。','S15']];
 function clinical() {
   main.innerHTML=wrap(pageTitle('CLINICAL USES','四类临床用途','围绕目标人群、决策时点和预期行动，分别查看已有证据与最早缺失的转化环节。')+'<div class="topic-grid">'+clinicalCopy.map(([use,title,description,boundary,table])=>{let t=arr(D.topics).find(t=>t.category==='clinical'&&(arr(t.use).includes(use)||arr(t.tableIds).includes(table)));return '<article class="topic-card"><div class="eyebrow">'+esc(table)+'</div><h2>'+title+'</h2><p>'+description+'</p><p class="boundary-note">'+boundary+'</p><div class="inline-actions">'+(t?'<a class="btn btn-primary" href="#topic/'+encodeURIComponent(t.id)+'">完整用途证据</a>':'<a class="btn btn-primary" href="downloads/'+table+'.docx" download>完整用途证据</a>')+'<a class="btn" href="'+searchPath({kind:'performances',use})+'">检索模型性能</a></div></article>';}).join('')+'</div><section class="section-block"><h2>继续查看研究缺口</h2><p class="muted">依据现有证据的身份、独立来源、测量条件和验证缺口，阅读后续研究任务。</p>'+arr(D.topics).filter(t=>t.category==='priorities').map(t=>'<details class="disclosure"><summary>'+esc(t.title)+'</summary>'+topicDetails(t)+'</details>').join('')+'</section>');
 }
 function topic(id) {
   const t=topicMap.get(id);if(!t){main.innerHTML=wrap('<div class="empty">未找到此主题。<a href="#science">返回科学解释</a></div>');return;}
   const clinical=t.category==='clinical';currentTopic=t;topicPage=1;topicQuery='';
   main.innerHTML=wrap('<div class="breadcrumb"><a href="#'+(clinical?'clinical':'science')+'">'+(clinical?'临床用途':'科学解释')+'</a><span>/</span><span>'+esc(t.title)+'</span></div>'+pageTitle(clinical?'CLINICAL EVIDENCE':'SCIENTIFIC EVIDENCE',t.title,t.description||'')+(clinical?'<details class="disclosure"><summary>阅读说明与科学边界</summary>'+detailFields(t.details)+'</details><section class="detail-section"><h2>完整用途证据</h2><input id="topic-q" class="glossary-search" aria-label="检索本专题证据" placeholder="在本专题内查名称、研究或证据条件…"><div id="topic-count" class="notice" role="status"></div><div id="topic-records"></div><div id="topic-pagination" class="pagination"></div></section>':topicDetails(t))+'<section class="detail-section"><h2>来源与完整补表</h2>'+(t.source?'<p class="source-citation">'+esc(str(t.source))+'</p>':'')+'<p>'+reportLinks(t)+'</p><p>'+tableLinks(t.tableIds)+'</p></section><div class="inline-actions"><a class="btn" href="'+searchPath({kind:clinical?'performances':'supports',use:arr(t.use)[0]||'',q:t.query||''})+'">'+(clinical?'继续检索此用途的性能记录':'检索全部通路与支持')+'</a><button class="btn" data-export-topic="'+esc(t.id)+'">下载主题记录</button></div>');
   if(clinical)renderTopicRecords();
 }
 function renderTopicRecords() {
   const rows=arr(currentTopic.records).filter(r=>{const hay=norm([r.title,arr(r.reportIds).join(' '),arr(r.details).map(d=>d.label+' '+str(d.value)).join(' ')].join(' '));return norm(topicQuery).split(/\s+/).filter(Boolean).every(word=>[word,...(aliases[word]||[])].some(w=>hay.includes(w)));});
   const pages=Math.max(1,Math.ceil(rows.length/20));topicPage=Math.min(topicPage,pages);
   document.getElementById('topic-count').textContent=num(rows.length)+'条专题条目 / 全部'+num(arr(currentTopic.records).length)+'条。专题条目按补表行组织，不能替代独立研究或性能记录计数。';
   document.getElementById('topic-records').innerHTML=rows.slice((topicPage-1)*20,topicPage*20).map((r,i)=>'<details class="disclosure"><summary>'+esc(r.title||r.id||'证据条目 '+((topicPage-1)*20+i+1))+'</summary>'+detailFields(r.details)+'<p class="source-note">'+reportLinks(r)+' · '+tableLinks(r.tableIds||currentTopic.tableIds)+'</p></details>').join('')||'<div class="empty">当前关键词无匹配专题条目。</div>';
   document.getElementById('topic-pagination').innerHTML=rows.length?'<button class="btn" data-topic-page="'+(topicPage-1)+'"'+(topicPage===1?' disabled':'')+'>上一页</button><span>'+topicPage+' / '+pages+'</span><button class="btn" data-topic-page="'+(topicPage+1)+'"'+(topicPage===pages?' disabled':'')+'>下一页</button>':'';localize();
 }
 function resources() {
   const figs=arr(C.figure_links||C.figure_map||C.figures||C.figure_mapping);
   main.innerHTML=wrap(pageTitle('RESOURCES & READING GUIDE','下载与使用说明','获取可离线使用的证据资源，查阅完整补表、计数单位及科学状态的含义。')+'<div class="resource-grid"><article class="resource-card"><h3>离线网站包</h3><p>完整解压后打开首页。检索、详情与本地导出无需联网；外部论文链接需要联网。</p><a class="btn btn-primary" href="https://github.com/DrTaoHuang/escc-metabolomic-evidence-atlas/releases/download/v1.0.0/ESCC_Evidence_Atlas_v1.0.0_Offline.zip" data-offline-bundle>下载离线网站</a></article><article class="resource-card"><h3>结构化证据</h3><p>完整观察、性能、支持、分组与来源关系。属于研究汇总证据，不能用作患者级训练数据。</p><a class="btn" href="evidence.json" download>下载完整证据 JSON</a></article><article class="resource-card"><h3>S1–S20完整补表</h3><p>可编辑Word总册，包含全部20张补表及目录导航；也可按下方索引下载独立表。</p><a class="btn" href="downloads/Supplementary_Tables.docx" download>下载完整补表 Word</a></article></div><section class="section-block"><h2>如何理解这些数量</h2><div class="chartless-info"><div class="muted-box">'+num(D.counts.reports)+'篇报告、'+num(D.counts.studies)+'个研究单元、'+num(D.counts.cohorts)+'个来源队列节点、'+num(D.counts.datasets)+'个分析数据集，属于不同实体层级。共享队列、内部划分、重复时点和多基质结果的关系分别保留。</div><div class="muted-box">'+num(D.counts.observations)+'条观察、'+num(D.counts.supports)+'条支持和'+num(D.counts.performances)+'条性能记录分别计数。'+num(D.counts.models)+'个模型标识不保证同一固定检测规则，也不表示相同次数的独立验证。</div></div><div class="notice">'+num(D.counts.groups)+'组候选结果：19组限定叙述、3675组图谱或方向展示、10组不能综合。当前合格定量Meta终点为0；未计算合并效应或汇总ROC。</div></section><section class="section-block"><h2>完整补表索引</h2><div class="table-scroll"><table class="table-index"><thead><tr><th scope="col">补表</th><th scope="col">内容</th><th scope="col">文件</th></tr></thead><tbody>'+arr(D.tables).map(t=>'<tr><td>'+esc(t.id)+'</td><td>'+esc(t.title)+'</td><td><a href="downloads/'+esc(t.id)+'.docx" download>Word</a></td></tr>').join('')+'</tbody></table></div></section>'+(figs.length?'<section class="section-block"><h2>与论文图的对应</h2>'+figs.map(f=>'<div class="glossary-row"><strong>'+esc(f.figure||f.id||f.label)+'</strong><p>'+esc(f.purpose||f.role||f.title||f.description)+' '+esc(arr(f.table_refs||f.tables).join('、'))+'</p></div>').join('')+'</section>':'')+'<section class="section-block"><h2>字段、缩写与状态释义</h2><p class="muted">同名缩写的不同含义分别保留；状态说明按原字段语境阅读。</p><input id="glossary-q" class="glossary-search" aria-label="查找缩写或字段释义" placeholder="查找：NR、UNC、MSI、AUC、计数单位…"><div id="glossary-list"></div></section><section class="section-block"><h2>引用与复用</h2><p class="muted">引用具体结果时，保留本图谱的研究范围与原始报告引文。每条记录可复制来源引文或下载完整字段。数据说明、来源关系和阴性或不确定结果应随复用保留。</p></section>');renderGlossary('');if(location.protocol==='file:'){const link=document.querySelector('[data-offline-bundle]');if(link){link.textContent='获取同一版本的离线包（需要联网）';link.removeAttribute('download');}}localize();
 }
 function renderGlossary(q) {
   const rows=arr(D.glossary).filter(g=>norm([g.term,g.title,g.description,arr(g.details).map(x=>x.label+' '+str(x.value)).join(' ')].join(' ')).includes(norm(q)));
   document.getElementById('glossary-list').innerHTML=rows.map(g=>'<details class="disclosure"><summary>'+esc(g.term||g.title||g.id)+(g.category?' · '+esc(g.category):'')+'</summary>'+(g.description?'<p class="muted" style="margin-bottom:12px">'+esc(g.description)+'</p>':'')+detailFields(g.details)+'</details>').join('')||'<p class="notice">当前关键词无匹配释义。</p>';localize();
 }
 function exportRows(rows,name) {
   download(name,JSON.stringify(rows.map(safePublic),null,2),'application/json;charset=utf-8');notify('已下载 '+num(rows.length)+'条完整记录');
 }
 function applyFilters(reset=true) {
   state.q=document.getElementById('query').value.trim();state.matrix=document.getElementById('matrix-filter').value;state.use=document.getElementById('use-filter').value;state.direction=document.getElementById('direction-filter').value;state.report=document.getElementById('report-filter').value;if(reset)state.page=1;renderResults();
 }
 function route() {
   clearTimeout(queryTimer);
   const hash=location.hash.slice(1)||'home', [name,query='']=hash.split('?'), params=new URLSearchParams(query), parts=name.split('/');
   document.querySelectorAll('[data-nav]').forEach(a=>{const active=a.dataset.nav===name||(parts[0]==='detail'&&a.dataset.nav==='search')||(parts[0]==='topic'&&a.dataset.nav===(topicMap.get(decodeURIComponent(parts[1]||''))?.category==='clinical'?'clinical':'science'));active?a.setAttribute('aria-current','page'):a.removeAttribute('aria-current');});
   document.getElementById('site-nav').classList.remove('open');document.getElementById('menu-toggle').setAttribute('aria-expanded','false');
   if(name==='home')home();else if(name==='search')search(params);else if(name==='science')science();else if(name==='clinical')clinical();else if(name==='resources')resources();else if(parts[0]==='detail')detail(parts[1],decodeURIComponent(parts[2]||''));else if(parts[0]==='topic')topic(decodeURIComponent(parts[1]||''));else home();
   main.dataset.view=parts[0];decoratePage(name);
   window.scrollTo(0,0);document.title=(parts[0]==='detail'?(indices[parts[1]]?.get(decodeURIComponent(parts[2]||''))?.title||'证据详情')+' · ':'')+'ESCC 代谢组证据图谱';localize();
 }
 document.addEventListener('submit',event=>{if(event.target.id==='home-search'){event.preventDefault();location.hash=searchPath({q:document.getElementById('home-q').value.trim(),kind:'observations'});}if(event.target.id==='result-search'){event.preventDefault();applyFilters();}});
 document.addEventListener('change',event=>{if(event.target.closest('.filter-panel'))applyFilters();});
 let queryTimer;document.addEventListener('input',event=>{if(event.target.id==='query'){clearTimeout(queryTimer);queryTimer=setTimeout(()=>applyFilters(),200);}if(event.target.id==='glossary-q')renderGlossary(event.target.value);if(event.target.id==='topic-q'){topicQuery=event.target.value;topicPage=1;renderTopicRecords();}});
 document.addEventListener('click',async event=>{
   if(event.target.closest('.skip-link')){event.preventDefault();main.focus();main.scrollIntoView({block:'start'});return;}
   const el=event.target.closest('button');if(!el)return;
   if(el.id==='menu-toggle'){const open=document.getElementById('site-nav').classList.toggle('open');el.setAttribute('aria-expanded',String(open));}
   if(el.dataset.query!==undefined)location.hash=searchPath({kind:el.dataset.kind||'observations',q:window.ESCC_I18N?.getLocale()==='en'?(aliases[el.dataset.query]?.[0]||el.dataset.query):el.dataset.query});
   if(el.dataset.browse)location.hash=searchPath({kind:el.dataset.browse,use:el.dataset.use||''});
   if(el.dataset.kindTab)location.hash=searchPath({kind:el.dataset.kindTab,q:state.q,matrix:state.matrix,use:state.use,report:state.report});
   if(el.id==='clear-filters'||el.dataset.clear)location.hash=searchPath({kind:state.kind});
   if(el.dataset.page){state.page=Number(el.dataset.page);renderResults();document.getElementById('result-count').scrollIntoView({block:'start'});}
   if(el.dataset.topicPage){topicPage=Number(el.dataset.topicPage);renderTopicRecords();document.getElementById('topic-count').scrollIntoView({block:'start'});}
   if(el.id==='export-results')exportRows(filtered,'ESCC_'+state.kind+'_filtered.json');
   if(el.dataset.exportOne)exportRows([indices[el.dataset.exportKind].get(el.dataset.exportOne)],'ESCC_'+el.dataset.exportOne+'.json');
   if(el.dataset.exportTopic)exportRows([topicMap.get(el.dataset.exportTopic)],'ESCC_'+el.dataset.exportTopic+'.json');
   if(el.dataset.copyCitation!==undefined){try{await navigator.clipboard.writeText(el.dataset.copyCitation);notify('已复制原报告引文');}catch{const area=document.createElement('textarea');area.value=el.dataset.copyCitation;document.body.append(area);area.select();const ok=document.execCommand('copy');area.remove();notify(ok?'已复制原报告引文':'当前浏览器未允许复制，请从原报告引文中选择文字。');}}
 });
 window.addEventListener('hashchange',route);
 window.ESCC_APP={counts:D.counts,filtered:()=>filtered.map(safePublic),state:()=>({...state}),getLocale:()=>window.ESCC_I18N?.getLocale()};
 route();
})();
