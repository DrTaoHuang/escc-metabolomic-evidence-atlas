'use strict';
(() => {
  const E=window.ESCC_EVIDENCE_EN||{}, U=window.ESCC_UI_EN||{};
  const dict=U.translations||{}, originalTexts=new WeakMap(), originalAttrs=new WeakMap();
  E['ESCC 代谢组证据图谱']='ESCC Metabolomic Evidence Atlas';
  let locale=new URL(location.href).searchParams.get('lang')==='zh'?'zh':'en';
  const reverse={};for(const [zh,en] of Object.entries(dict))if(!reverse[en])reverse[en]=zh;
  Object.assign(reverse,{'Language':'语言','Loading the evidence atlas…':'正在加载证据图谱…'});
  Object.assign(dict,{'语言':'Language','正在加载证据图谱…':'Loading the evidence atlas…','在线资源':'Online resources','获取同一版本的离线包（需要联网）':'Get this version offline (internet required)','当前网站已完整解压，可直接离线使用。':'This atlas is fully extracted and ready for offline use.','已保留原始科学名称及引文文字。':'Original scientific names and citation wording are retained.'});
  const escapeRegex=s=>s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
  const patterns=(U.patterns||[]).slice().sort((a,b)=>b.source.length-a.source.length).map(item=>{
    const ids=[];let re='',last=0;
    for(const match of item.source.matchAll(/\{(\d+)\}/g)){re+=escapeRegex(item.source.slice(last,match.index))+'([\\s\\S]*?)';ids.push(Number(match[1]));last=match.index+match[0].length;}
    re+=escapeRegex(item.source.slice(last));return {...item,ids,re:new RegExp('^'+re+'$')};
  });
  const evidenceContext='.detail-fields dd,.evidence-strip dd,.record-title,.record-summary dd,.record-side .direction,.source-citation,.mini-record,.detail-header h1,.topic-item h3,.topic-item p';
  function english(text,element){
    for(const item of U.scopedTranslations||[])if(text===item.source&&element?.matches?.(item.selector))return item.target;
    if(element?.closest(evidenceContext)){
      const controlled=new Set(['组织','血清','血浆','尿液','粪便','唾液','呼出气相关样本','外泌体','其他或未明确','升高','降低','方向混合','无法确定','未报告','不适用','未明确']);
      if(element.closest('.evidence-strip dd,.record-side .direction')&&controlled.has(text))return dict[text]||E[text]||text;
      return E[text]||text;
    }
    if(Object.hasOwn(dict,text))return dict[text];
    if(Object.hasOwn(E,text))return E[text];
    for(const item of patterns){const match=item.re.exec(text);if(match){const captures={};item.ids.forEach((id,i)=>captures[id]=match[i+1]);return item.target.replace(/\{(\d+)\}/g,(_,id)=>{const value=captures[Number(id)]||'';return (item.captureKinds||[])[Number(id)]==='approvedEvidenceText'?(E[value]||value):value;});}}
    if(element?.closest('.side-card,.breadcrumb,.record-meta,#result-count')){
      const prefixes={'报告：':'Report: ','研究单元：':'Study units: ','来源队列节点：':'Source-cohort nodes: ','分析数据集：':'Analytic datasets: ','关键词：':'Keyword: '};
      for(const [from,to] of Object.entries(prefixes))if(text.startsWith(from))return to+(E[text.slice(from.length)]||text.slice(from.length));
      if(text==='全部')return 'All';
    }
    return text;
  }
  function translate(text,element){
    const spaces=/^(\s*)([\s\S]*?)(\s*)$/.exec(text),core=spaces[2];
    if(!core)return text;
    const translated=locale==='en'?english(core,element):(element?.closest(evidenceContext)?core:(reverse[core]||core));
    return spaces[1]+translated+spaces[3];
  }
  function apply(){
    document.documentElement.lang=locale==='en'?'en':'zh-CN';
    const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);
    const nodes=[];while(walker.nextNode())nodes.push(walker.currentNode);
    for(const node of nodes){const parent=node.parentElement;if(!parent||parent.closest('script,style,#language-switch,[data-no-localize]'))continue;
      if(!originalTexts.has(node))originalTexts.set(node,node.data);
      node.data=translate(originalTexts.get(node),parent);
    }
    for(const el of document.querySelectorAll('[aria-label],[placeholder],[title]')){
      if(el.closest('#language-switch,[data-no-localize]'))continue;
      let values=originalAttrs.get(el);if(!values){values={};originalAttrs.set(el,values);}
      for(const name of ['aria-label','placeholder','title'])if(el.hasAttribute(name)){
        if(!(name in values))values[name]=el.getAttribute(name);el.setAttribute(name,translate(values[name],el));
      }
    }
    const language=document.getElementById('language-switch');if(language)language.value=locale;
    document.title=document.title.replace(/ESCC (?:代谢组证据图谱|Metabolomic Evidence Atlas)$/,'ESCC '+(locale==='en'?'Metabolomic Evidence Atlas':'代谢组证据图谱'));
    const meta=document.querySelector('meta[name="description"]');if(meta)meta.content=locale==='en'?'Search human ESCC metabolomic evidence by molecule, context, clinical use and source.':'检索人体食管鳞状细胞癌代谢组证据，查看分子身份、研究情境、验证与来源。';
  }
  function setLanguage(value){
    locale=value==='zh'?'zh':'en';
    const address=new URL(location.href);if(locale==='zh')address.searchParams.set('lang','zh');else address.searchParams.delete('lang');
    try{history.replaceState(null,'',address.href);}catch{}
    apply();
  }
  document.addEventListener('change',event=>{if(event.target.id==='language-switch')setLanguage(event.target.value);});
  document.addEventListener('DOMContentLoaded',apply);
  window.ESCC_I18N={apply,setLanguage,getLocale:()=>locale,evidenceText:value=>E[value]||value,uiText:value=>dict[value]||value};
})();
